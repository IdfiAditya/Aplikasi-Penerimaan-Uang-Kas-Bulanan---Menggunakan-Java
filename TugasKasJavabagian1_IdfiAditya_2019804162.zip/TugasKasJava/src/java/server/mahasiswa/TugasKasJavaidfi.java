/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server.mahasiswa;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
/**
 *
 * @author acer
 */

    @WebService(serviceName = "KasBulanan")
public class TugasKasJavaidfi {
/*Panggil Koneksi MySQL*/
KoneksiMySQL kon = new KoneksiMySQL();
Connection con;
PreparedStatement ps;
ResultSet rs;
/*Selesai Panggil Koneksi MySQL*/
/*-----------------------------------------------------------------------------------------------------*/
/*Get Snack*/
@WebMethod(operationName = "getMahasiswa")
public List getMahasiswa(
@WebParam(name = "npm") int npm,
        
@WebParam(name = "nama") String nama,
@WebParam(name = "kelas") String kelas,
@WebParam(name = "bulan") String bulan,
@WebParam(name = "pembayaran") String pembayaran,
@WebParam(name = "q") String q ) 
{
    List mahasiswa = new ArrayList();
    try 
    {
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/db_tugaskas", "root", "");
        Statement st = conn.createStatement();
        con = kon.getCon();
        
        ps = con.prepareStatement("select * from tb_kas where npm=?");
        ps.setInt(1, npm);
        ResultSet rst = ps.executeQuery();
        while (rst.next()) 
        {
            mahasiswa.add("<div class=\"form-group\">\n" +
            " <label class=\"control-label col-sm-1\">Npm</label>\n" +
            " <div class=\"col-sm-2\">\n" +
            " <input type=\"text\" class=\"form-control\" name=\"npm\" value=\""+rst.getInt("npm")+"\" readonly=\"true\">\n" +
            " </div>\n" +
            " </div>\n" +
            " \n" +
            " <div class=\"form-group\">\n" +
            " <label class=\"control-label col-sm-1\">Nama</label>\n" +
            " <div class=\"col-sm-2\">\n" +
            " <input type=\"text\" class=\"form-control\" name=\"nama\" value=\""+rst.getString("nama")+"\">\n" +
            " </div>\n" +
            " </div>\n" +
            " \n" +
            " <div class=\"form-group\">\n" +
            " <label class=\"control-label col-sm-1\">Kelas</label>\n" +
            " <div class=\"col-sm-2\">\n" +
            " <input type=\"text\" class=\"form-control\" name=\"kelas\" value=\""+rst.getString("kelas")+"\">\n" +
            " </div>\n" +
            " </div>\n" +
            " \n" +
            " <div class=\"form-group\">\n" +
            " <label class=\"control-label col-sm-1\">Bulan</label>\n" +
            " <div class=\"col-sm-2\">\n" +
            " <input type=\"text\" class=\"form-control\" name=\"bulan\" value=\""+rst.getString("bulan")+"\">\n" +
            " </div>\n" +
            " </div>\n" +
            " \n" +
            " <div class=\"form-group\">\n" +
            " <label class=\"control-label col-sm-1\">Pembayaran</label>\n" +
            " <div class=\"col-sm-2\">\n" +
            " <input type=\"text\" class=\"form-control\" name=\"pembayaran\" value=\""+rst.getString("pembayaran")+"\">\n" +
            " </div>\n" +
            " </div>\n" +
            " \n" +
            " </div>");
        }      
    }
    catch (Exception ex) 
    {
        System.out.println(ex.getMessage());
    }
    return mahasiswa;
}
/*Selesai Get Snack*/
/*-----------------------------------------------------------------------------------------------------*/
/*Selesai Tambah Snack*/
@WebMethod(operationName = "addMahasiswa")
public void addMahasiswa(
@WebParam(name = "npm") int npm,
@WebParam(name = "nama") String nama,
@WebParam(name = "kelas") String kelas,
@WebParam(name = "bulan") String bulan, 
@WebParam(name = "pembayaran") String pembayaran ) 
{
    try
    {
        con = kon.getCon();
        ps = con.prepareStatement("insert into tb_kas (?,?,?,?,?)");
        ps.setInt(1, npm);
        ps.setString(2, nama);
        ps.setString(3, kelas);
        ps.setString(4, bulan);
        ps.setString(5, pembayaran);
        ps.executeUpdate();
        } catch (Exception ex) {
        System.out.println(ex.getMessage());
    }
}
/*Selesai Tambah Snack*/
/*-----------------------------------------------------------------------------------------------------*/
/*Hapus Snack*/
@WebMethod(operationName = "delMahasiswa")
public void delMahasiswa(
@WebParam(name = "npm") int npm) 
{
    try
    {
        con = kon.getCon();
        ps = con.prepareStatement("delete from tb_kas where npm = ?");
        ps.setInt(1, npm);
        ps.executeUpdate();
        } catch (Exception e) {
        System.out.println("Failed to remove student because " + e.toString());
    }
}
/*Selesai Hapus Snack*/
/*-----------------------------------------------------------------------------------------------------*/
/*Edit Snack*/
@WebMethod(operationName = "editMahasiswa")
public void editMahasiswa(
@WebParam(name = "npm") int npm,
@WebParam(name = "nama") String nama,
@WebParam(name = "kelas") String kelas,
@WebParam(name = "bulan") String bulan, 
@WebParam(name = "pembayaran") String pembayaran ) 
{
    try 
    {
        con = kon.getCon();
        ps = con.prepareStatement("update tb_kas set nama=?,kelas=?,bulan=?,pembayaran=? where npm=?");
        ps.setString(1, nama);
        ps.setString(2, kelas);
        ps.setString(3, bulan);
        ps.setString(4, pembayaran);
         ps.setInt(5, npm);
        ps.executeUpdate();
        } catch (Exception e) {
        System.out.println("Failed to edit student because " + e.toString());
    }
}
/*Selesai Edit Snack*/
/*-----------------------------------------------------------------------------------------------------*/
@WebMethod(operationName = "tampilMahasiswa")
public List tampilMahasiswa() {
    List daftar = new ArrayList();
    String sql_daftar = "select * from tb_kas";
    try {
        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db_tugaskas", "root", "");
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery(sql_daftar);
       
        while (rs.next())
        {
            daftar.add("<td>" + rs.getInt("npm") + "</td>"
                    + "<td>" + rs.getString("nama") + "</td>"
                    + "<td>" + rs.getString("kelas") + "</td>"
                    + "<td>" + rs.getString("bulan") + "</td>"
                    + "<td>" + rs.getString("pembayaran")+"</td>");
        }
        con.close();
        } catch (Exception ex) {
        System.out.println(ex.getMessage());
        }
        return daftar;
    }
}

